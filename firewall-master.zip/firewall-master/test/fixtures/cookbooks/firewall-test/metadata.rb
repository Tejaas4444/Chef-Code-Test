name 'firewall-test'
version '1.0.0'

depends 'chef-sugar'
depends 'firewall'
